import { getStore } from '@netlify/blobs';

export const store = getStore('suite19-pool');

export const defaultConfig = {
  title: 'Suite 19 Knoxville Nationals Pool',
  activeNight: 'wednesday',
  locked: { wednesday:false, thursday:false, friday:false, saturday:false },
  nights: {
    wednesday: { label:'Wednesday', mode:'five', drivers:[] },
    thursday: { label:'Thursday', mode:'five', drivers:[] },
    friday: { label:'Friday', mode:'five', drivers:[] },
    saturday: { label:'Saturday', mode:'pods', pods:[[],[],[],[],[],[]] }
  },
  results: { wednesday:{}, thursday:{}, friday:{}, saturday:{} }
};

export async function getConfig(){
  return (await store.get('config', { type:'json' })) || defaultConfig;
}
export async function saveConfig(config){ await store.setJSON('config', config); }
export function json(statusCode, body){ return { statusCode, headers:{'content-type':'application/json','cache-control':'no-store'}, body:JSON.stringify(body) }; }
export function norm(s=''){ return String(s).trim().toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''); }
export function adminOK(event){
  const pin = process.env.ADMIN_PIN || '1919';
  const given = event.headers['x-admin-pin'] || event.queryStringParameters?.pin || '';
  return given === pin;
}
export function scoreForFinish(pos){ const p=Number(pos); return Number.isFinite(p)&&p>0 ? Math.max(0,202-2*p):0; }
