import { getConfig, json } from './_lib.mjs';
export default async () => json(200, await getConfig());
