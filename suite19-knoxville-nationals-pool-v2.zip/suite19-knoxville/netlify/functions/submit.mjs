import { getConfig, json, norm, store } from './_lib.mjs';

export default async (event) => {
  if(event.httpMethod !== 'POST') return json(405,{error:'POST only'});
  let body; try{ body=JSON.parse(event.body||'{}'); }catch{ return json(400,{error:'Invalid request'}); }
  const name=String(body.name||'').trim(); const night=String(body.night||''); const picks=Array.isArray(body.picks)?body.picks:[];
  if(!name) return json(400,{error:'Enter your name.'});
  const cfg=await getConfig(); const n=cfg.nights[night];
  if(!n) return json(400,{error:'Unknown night.'});
  if(cfg.locked?.[night]) return json(403,{error:'Picks are locked for this night.'});
  if(n.mode==='five'){
    const allowed=new Set((n.drivers||[]).map(d=>d.id));
    if(picks.length!==5 || new Set(picks).size!==5) return json(400,{error:'Select exactly 5 different cars.'});
    if(picks.some(p=>!allowed.has(p))) return json(400,{error:'One of those drivers is not available tonight.'});
  } else {
    if(picks.length!==6) return json(400,{error:'Pick one car from each pod.'});
    for(let i=0;i<6;i++) if(!(n.pods?.[i]||[]).some(d=>d.id===picks[i])) return json(400,{error:`Choose one valid driver from Pod ${i+1}.`});
  }
  const entry={name,night,picks,submittedAt:new Date().toISOString()};
  await store.setJSON(`entries/${night}/${norm(name)}`,entry);
  return json(200,{ok:true,entry});
};
