import { adminOK, getConfig, json, saveConfig, scoreForFinish, store } from './_lib.mjs';

async function listEntries(night){
  const out=[]; let cursor;
  do {
    const page=await store.list({prefix:`entries/${night}/`,cursor});
    for(const b of page.blobs||[]) { const x=await store.get(b.key,{type:'json'}); if(x) out.push(x); }
    cursor=page.next_cursor;
  } while(cursor);
  return out.sort((a,b)=>a.name.localeCompare(b.name));
}
function scoreEntries(entries,night,cfg){
  const results=cfg.results?.[night]||{};
  return entries.map(e=>{
    const pts=e.picks.reduce((sum,id)=> sum + (night==='wednesday'||night==='thursday' ? Number(results[id]||0) : scoreForFinish(results[id])),0);
    return {...e,score:pts};
  }).sort((a,b)=>b.score-a.score || a.name.localeCompare(b.name));
}
async function allNightData(cfg){
  const nights={};
  for(const night of Object.keys(cfg.nights)){
    const entries=await listEntries(night);
    nights[night]=scoreEntries(entries,night,cfg);
  }
  const names=new Set(Object.values(nights).flat().map(e=>e.name));
  const overall=[...names].map(name=>{
    const perNight={}; let total=0;
    for(const night of Object.keys(nights)){
      const e=nights[night].find(x=>x.name===name); perNight[night]=e?.score||0; total+=e?.score||0;
    }
    return {name,total,perNight};
  }).sort((a,b)=>b.total-a.total || a.name.localeCompare(b.name));
  return {nights,overall};
}

export default async (event)=>{
  if(!adminOK(event)) return json(401,{error:'Wrong organizer PIN'});
  const cfg=await getConfig();
  if(event.httpMethod==='GET'){
    const night=event.queryStringParameters?.night || cfg.activeNight;
    const entries=scoreEntries(await listEntries(night),night,cfg);
    const includeAll=event.queryStringParameters?.all==='1';
    const extra=includeAll?await allNightData(cfg):{};
    return json(200,{config:cfg,entries,...extra});
  }
  if(event.httpMethod!=='POST') return json(405,{error:'Unsupported'});
  let body; try{body=JSON.parse(event.body||'{}')}catch{return json(400,{error:'Bad JSON'})}
  if(body.action==='saveConfig'){
    const next=body.config; if(!next?.nights) return json(400,{error:'Bad config'});
    await saveConfig(next); return json(200,{ok:true,config:next});
  }
  if(body.action==='deleteEntry'){
    if(!body.night||!body.key) return json(400,{error:'Missing entry'});
    await store.delete(`entries/${body.night}/${body.key}`); return json(200,{ok:true});
  }
  return json(400,{error:'Unknown action'});
};
