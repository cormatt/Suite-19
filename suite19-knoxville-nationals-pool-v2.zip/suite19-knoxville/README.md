# Suite 19 Knoxville Nationals Pool — V2

A phone-first web app for the 2026 410 Knoxville Nationals pool.

## Contestant experience

1. Open one link on a phone.
2. Enter a name.
3. Wednesday / Thursday / Friday: tap exactly 5 cars.
4. Saturday: tap one car from each 4-car pod.
5. Submit. A player may resubmit under the same name until that night is locked.

No account, spreadsheet, or app install is required.

## Organizer experience

Open `/admin.html`, enter the organizer PIN, and use five views:

- **Manage Night** — choose active night, load drivers/pods, see entries, lock picks, enter race results.
- **Pick Board** — automatically lays out every player and every pick.
- **Pick Analysis** — automatically calculates ownership %, most popular driver, most unique lineup, chalkiest lineup, lone-wolf picks, unpicked cars, common pairings, and a swing pick.
- **Results Recap** — after results are entered, automatically shows the nightly winner, margin, full standings, a contrarian success, and popular pick that hurt.
- **Overall Standings** — cumulative score across all four nights.

Every report includes **SAVE SHAREABLE PNG**, which creates a dark/orange Suite 19 graphic in the browser.

### Definitions used in Pick Analysis

- **Most unique lineup**: highest rarity score, calculated by giving more weight to drivers selected by fewer entrants.
- **Chalkiest lineup**: highest sum of driver ownership counts.
- **Lone-wolf pick**: a driver selected by exactly one entrant.
- **Swing pick**: ownership closest to 50% of the field.
- **Best contrarian call**: among the strongest-performing selected drivers, the one with the lowest ownership.
- **Chalk that hurt**: among the most-owned selected drivers, the lowest-performing one.

## Scoring

- Wednesday / Thursday: enter the official Knoxville qualifying-night point total for each car.
- Friday / Saturday: enter A-Main finishing position. The app converts the finish to 200, 198, 196, 194, ... automatically.

## Deploy on Netlify

### GitHub + Netlify

1. Create a new GitHub repository.
2. Upload all files from this folder to the repository, preserving the folders.
3. In Netlify choose **Add new project → Import an existing project → GitHub**.
4. Select the repository.
5. Netlify reads `netlify.toml`; no build command is required.
6. Deploy.
7. In Netlify open **Project configuration → Environment variables** and add `ADMIN_PIN` with a PIN only you know.
8. Redeploy after adding the PIN.

Netlify Functions and Netlify Blobs store the pool configuration and submissions. No separate database account is needed for this small pool.

### Links

- Public picker: `https://YOUR-SITE.netlify.app/`
- Organizer: `https://YOUR-SITE.netlify.app/admin.html`

## Entering drivers

Use one driver per line:

```text
49 | Brad Sweet
57 | Carson Macedo
1S | Logan Schuchart
```

For Saturday, each of the six pods has its own four-line box.

## Entering results

Wednesday/Thursday:

```text
49 | 485
57 | 472
```

Friday/Saturday (finishing position):

```text
49 | 1
57 | 4
```

## Security note

The code defaults to organizer PIN `1919` only if no environment variable is configured. Set `ADMIN_PIN` before sharing the site.
